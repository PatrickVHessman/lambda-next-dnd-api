"use strict";
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ Home; }
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../styles/Home.module.css */ "./styles/Home.module.css");
/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/layout */ "./components/layout.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_4__);
/* module decorator */ module = __webpack_require__.hmd(module);


var _jsxFileName = "C:\\Users\\patri\\Documents\\webDevTraining\\1upHealth assessment\\lambda-take4\\pages\\index.js",
    _s = $RefreshSig$();






function Home() {
  _s();

  var _this = this;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]),
      races = _useState[0],
      setRaces = _useState[1];

  var _useState2 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(""),
      raceName = _useState2[0],
      setRaceName = _useState2[1];

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(""),
      alignment = _useState3[0],
      setAlignment = _useState3[1];

  var _useState4 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(""),
      age = _useState4[0],
      setAge = _useState4[1];

  var _useState5 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(""),
      size = _useState5[0],
      setSize = _useState5[1];

  var _useState6 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(""),
      language = _useState6[0],
      setLanguage = _useState6[1];

  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(function () {
    axios__WEBPACK_IMPORTED_MODULE_4___default().get('https://8jxxb7mgec.execute-api.us-east-1.amazonaws.com/prod/races/').then(function (res) {
      setRaces(res.data[0].results);
      setAlignment(res.data[1].alignment);
      setRaceName(res.data[1].name);
      setAge(res.data[1].age);
      setSize(res.data[1].size_description);
      setLanguage(res.data[1].language_desc);
    });
  }, []);

  var selectRace = function selectRace(el) {
    axios__WEBPACK_IMPORTED_MODULE_4___default().get("https://8jxxb7mgec.execute-api.us-east-1.amazonaws.com/prod/races/".concat(el)).then(function (res) {
      setAlignment(res.data.alignment);
      setRaceName(res.data.name);
      setAge(res.data.age);
      setSize(res.data.size_description);
      setLanguage(res.data.language_desc);
    });
  }; // Mapping out the API response in a separate function instead of on the main render in case of errors on the API call.


  var RaceList = function RaceList() {
    if (races !== undefined) {
      return races.map(function (race) {
        return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
          className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_5___default().card),
          style: {
            display: "block"
          },
          onClick: function onClick() {
            return selectRace(race.index);
          },
          children: race.name
        }, race.index, false, {
          fileName: _jsxFileName,
          lineNumber: 42,
          columnNumber: 14
        }, _this);
      });
    } else {
      return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        children: "Sorry, an error has occurred!"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 45,
        columnNumber: 14
      }, _this);
    }
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_layout__WEBPACK_IMPORTED_MODULE_3__.default, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("title", {
        children: "Dungeons and Dragons API Browser"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 52,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("meta", {
        name: "description",
        content: "Generated by create next app"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 53,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("link", {
        rel: "icon",
        href: "/favicon.ico"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 54,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 51,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_5___default().mainCard),
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h3", {
        children: raceName
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 57,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("b", {
          children: "Alignment:"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 58,
          columnNumber: 12
        }, this), " ", alignment]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 58,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("b", {
          children: "Age:"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 59,
          columnNumber: 12
        }, this), " ", age]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 59,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("b", {
          children: "Size:"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 60,
          columnNumber: 12
        }, this), " ", size]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 60,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("b", {
          children: "Languages:"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 61,
          columnNumber: 12
        }, this), " ", language]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 61,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 56,
      columnNumber: 9
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h4", {
      style: {
        textAlign: "center"
      },
      children: "More Races"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 63,
      columnNumber: 5
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_5___default().linkContainer),
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(RaceList, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 65,
        columnNumber: 7
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 64,
      columnNumber: 5
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 50,
    columnNumber: 5
  }, this);
}

_s(Home, "yOr3KbE7Dn12mGR6hyuU2ePBr0A=");

_c = Home;

var _c;

$RefreshReg$(_c, "Home");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguYWQwZWRlZDI1ZWQ5ZDdiMTk3NjcuaG90LXVwZGF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBRWUsU0FBU00sSUFBVCxHQUFnQjtBQUFBOztBQUFBOztBQUFBLGtCQUVKSiwrQ0FBUSxDQUFDLEVBQUQsQ0FGSjtBQUFBLE1BRXRCSyxLQUZzQjtBQUFBLE1BRWhCQyxRQUZnQjs7QUFBQSxtQkFHSU4sK0NBQVEsQ0FBQyxFQUFELENBSFo7QUFBQSxNQUd0Qk8sUUFIc0I7QUFBQSxNQUdaQyxXQUhZOztBQUFBLG1CQUlNUiwrQ0FBUSxDQUFDLEVBQUQsQ0FKZDtBQUFBLE1BSXRCUyxTQUpzQjtBQUFBLE1BSVhDLFlBSlc7O0FBQUEsbUJBS05WLCtDQUFRLENBQUMsRUFBRCxDQUxGO0FBQUEsTUFLdEJXLEdBTHNCO0FBQUEsTUFLakJDLE1BTGlCOztBQUFBLG1CQU1KWiwrQ0FBUSxDQUFDLEVBQUQsQ0FOSjtBQUFBLE1BTXRCYSxJQU5zQjtBQUFBLE1BTWhCQyxPQU5nQjs7QUFBQSxtQkFPSWQsK0NBQVEsQ0FBQyxFQUFELENBUFo7QUFBQSxNQU90QmUsUUFQc0I7QUFBQSxNQU9aQyxXQVBZOztBQVM3QmYsRUFBQUEsZ0RBQVMsQ0FBQyxZQUFNO0FBQ1pFLElBQUFBLGdEQUFBLENBQVUsb0VBQVYsRUFBZ0ZlLElBQWhGLENBQXFGLFVBQUFDLEdBQUcsRUFBSTtBQUM1RmIsTUFBQUEsUUFBUSxDQUFDYSxHQUFHLENBQUNDLElBQUosQ0FBUyxDQUFULEVBQVlDLE9BQWIsQ0FBUjtBQUNBWCxNQUFBQSxZQUFZLENBQUNTLEdBQUcsQ0FBQ0MsSUFBSixDQUFTLENBQVQsRUFBWVgsU0FBYixDQUFaO0FBQ0FELE1BQUFBLFdBQVcsQ0FBQ1csR0FBRyxDQUFDQyxJQUFKLENBQVMsQ0FBVCxFQUFZRSxJQUFiLENBQVg7QUFDQVYsTUFBQUEsTUFBTSxDQUFDTyxHQUFHLENBQUNDLElBQUosQ0FBUyxDQUFULEVBQVlULEdBQWIsQ0FBTjtBQUNBRyxNQUFBQSxPQUFPLENBQUNLLEdBQUcsQ0FBQ0MsSUFBSixDQUFTLENBQVQsRUFBWUcsZ0JBQWIsQ0FBUDtBQUNBUCxNQUFBQSxXQUFXLENBQUNHLEdBQUcsQ0FBQ0MsSUFBSixDQUFTLENBQVQsRUFBWUksYUFBYixDQUFYO0FBQ0QsS0FQQztBQVFILEdBVFEsRUFTTixFQVRNLENBQVQ7O0FBV0EsTUFBTUMsVUFBVSxHQUFHLFNBQWJBLFVBQWEsQ0FBQ0MsRUFBRCxFQUFRO0FBQ3ZCdkIsSUFBQUEsZ0RBQUEsNkVBQStFdUIsRUFBL0UsR0FBcUZSLElBQXJGLENBQTBGLFVBQUFDLEdBQUcsRUFBSTtBQUNqR1QsTUFBQUEsWUFBWSxDQUFDUyxHQUFHLENBQUNDLElBQUosQ0FBU1gsU0FBVixDQUFaO0FBQ0FELE1BQUFBLFdBQVcsQ0FBQ1csR0FBRyxDQUFDQyxJQUFKLENBQVNFLElBQVYsQ0FBWDtBQUNBVixNQUFBQSxNQUFNLENBQUNPLEdBQUcsQ0FBQ0MsSUFBSixDQUFTVCxHQUFWLENBQU47QUFDQUcsTUFBQUEsT0FBTyxDQUFDSyxHQUFHLENBQUNDLElBQUosQ0FBU0csZ0JBQVYsQ0FBUDtBQUNBUCxNQUFBQSxXQUFXLENBQUNHLEdBQUcsQ0FBQ0MsSUFBSixDQUFTSSxhQUFWLENBQVg7QUFDRCxLQU5DO0FBT0gsR0FSRCxDQXBCNkIsQ0E4QjdCOzs7QUFDQSxNQUFNRyxRQUFRLEdBQUcsU0FBWEEsUUFBVyxHQUFNO0FBQ3JCLFFBQUl0QixLQUFLLEtBQUt1QixTQUFkLEVBQXlCO0FBQ3ZCLGFBQU92QixLQUFLLENBQUN3QixHQUFOLENBQVUsVUFBQUMsSUFBSSxFQUFJO0FBQ3pCLDRCQUFPO0FBQUcsbUJBQVMsRUFBRS9CLHFFQUFkO0FBQTRDLGVBQUssRUFBRTtBQUFDaUMsWUFBQUEsT0FBTyxFQUFFO0FBQVYsV0FBbkQ7QUFBdUUsaUJBQU8sRUFBRTtBQUFBLG1CQUFNUCxVQUFVLENBQUNLLElBQUksQ0FBQ0csS0FBTixDQUFoQjtBQUFBLFdBQWhGO0FBQUEsb0JBQStHSCxJQUFJLENBQUNSO0FBQXBILFdBQWdDUSxJQUFJLENBQUNHLEtBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVA7QUFDRCxPQUZRLENBQVA7QUFFQyxLQUhILE1BSUs7QUFDSCwwQkFBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFQO0FBQ0Q7QUFDRixHQVJEOztBQVVBLHNCQUNFLDhEQUFDLHVEQUFEO0FBQUEsNEJBQ0UsOERBQUMsa0RBQUQ7QUFBQSw4QkFDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGLGVBRUU7QUFBTSxZQUFJLEVBQUMsYUFBWDtBQUF5QixlQUFPLEVBQUM7QUFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUZGLGVBR0U7QUFBTSxXQUFHLEVBQUMsTUFBVjtBQUFpQixZQUFJLEVBQUM7QUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGLGVBTUk7QUFBSyxlQUFTLEVBQUVsQyx5RUFBaEI7QUFBQSw4QkFDQTtBQUFBLGtCQUFLUTtBQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FEQSxlQUVBO0FBQUEsZ0NBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQUgsRUFBcUIsR0FBckIsRUFBMEJFLFNBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUZBLGVBR0E7QUFBQSxnQ0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFBSCxFQUFlLEdBQWYsRUFBb0JFLEdBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUhBLGVBSUE7QUFBQSxnQ0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFBSCxFQUFnQixHQUFoQixFQUFxQkUsSUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSkEsZUFLQTtBQUFBLGdDQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUFILEVBQXFCLEdBQXJCLEVBQTBCRSxRQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FMQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFOSixlQWFBO0FBQUksV0FBSyxFQUFFO0FBQUNvQixRQUFBQSxTQUFTLEVBQUU7QUFBWixPQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBYkEsZUFjQTtBQUFLLGVBQVMsRUFBRXBDLDhFQUFoQjtBQUFBLDZCQUNFLDhEQUFDLFFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFkQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQXFCRDs7R0E5RHVCSzs7S0FBQUEiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvaW5kZXguanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IEhlYWQgZnJvbSAnbmV4dC9oZWFkJ1xuaW1wb3J0IHN0eWxlcyBmcm9tICcuLi9zdHlsZXMvSG9tZS5tb2R1bGUuY3NzJ1xuaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcblxuaW1wb3J0IExheW91dCBmcm9tICcuLi9jb21wb25lbnRzL2xheW91dCc7XG5pbXBvcnQgYXhpb3MgZnJvbSAnYXhpb3MnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBIb21lKCkge1xuXG4gIGNvbnN0IFtyYWNlcyxzZXRSYWNlc10gPSB1c2VTdGF0ZShbXSk7XG4gIGNvbnN0IFtyYWNlTmFtZSwgc2V0UmFjZU5hbWVdICA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbYWxpZ25tZW50LCBzZXRBbGlnbm1lbnRdICA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbYWdlLCBzZXRBZ2VdICA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbc2l6ZSwgc2V0U2l6ZV0gID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtsYW5ndWFnZSwgc2V0TGFuZ3VhZ2VdICA9IHVzZVN0YXRlKFwiXCIpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICBheGlvcy5nZXQoJ2h0dHBzOi8vOGp4eGI3bWdlYy5leGVjdXRlLWFwaS51cy1lYXN0LTEuYW1hem9uYXdzLmNvbS9wcm9kL3JhY2VzLycpLnRoZW4ocmVzID0+IHtcbiAgICAgIHNldFJhY2VzKHJlcy5kYXRhWzBdLnJlc3VsdHMpO1xuICAgICAgc2V0QWxpZ25tZW50KHJlcy5kYXRhWzFdLmFsaWdubWVudCk7XG4gICAgICBzZXRSYWNlTmFtZShyZXMuZGF0YVsxXS5uYW1lKTtcbiAgICAgIHNldEFnZShyZXMuZGF0YVsxXS5hZ2UpO1xuICAgICAgc2V0U2l6ZShyZXMuZGF0YVsxXS5zaXplX2Rlc2NyaXB0aW9uKTtcbiAgICAgIHNldExhbmd1YWdlKHJlcy5kYXRhWzFdLmxhbmd1YWdlX2Rlc2MpO1xuICAgIH0pXG4gIH0sIFtdKTtcblxuICBjb25zdCBzZWxlY3RSYWNlID0gKGVsKSA9PiB7XG4gICAgICBheGlvcy5nZXQoYGh0dHBzOi8vOGp4eGI3bWdlYy5leGVjdXRlLWFwaS51cy1lYXN0LTEuYW1hem9uYXdzLmNvbS9wcm9kL3JhY2VzLyR7ZWx9YCkudGhlbihyZXMgPT4ge1xuICAgICAgc2V0QWxpZ25tZW50KHJlcy5kYXRhLmFsaWdubWVudCk7XG4gICAgICBzZXRSYWNlTmFtZShyZXMuZGF0YS5uYW1lKTtcbiAgICAgIHNldEFnZShyZXMuZGF0YS5hZ2UpO1xuICAgICAgc2V0U2l6ZShyZXMuZGF0YS5zaXplX2Rlc2NyaXB0aW9uKTtcbiAgICAgIHNldExhbmd1YWdlKHJlcy5kYXRhLmxhbmd1YWdlX2Rlc2MpO1xuICAgIH0pO1xuICB9XG5cbiAgLy8gTWFwcGluZyBvdXQgdGhlIEFQSSByZXNwb25zZSBpbiBhIHNlcGFyYXRlIGZ1bmN0aW9uIGluc3RlYWQgb2Ygb24gdGhlIG1haW4gcmVuZGVyIGluIGNhc2Ugb2YgZXJyb3JzIG9uIHRoZSBBUEkgY2FsbC5cbiAgY29uc3QgUmFjZUxpc3QgPSAoKSA9PiB7XG4gICAgaWYgKHJhY2VzICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIHJldHVybiByYWNlcy5tYXAocmFjZSA9PiB7XG4gICAgICByZXR1cm4gPGEgY2xhc3NOYW1lPXtzdHlsZXMuY2FyZH0ga2V5PXtyYWNlLmluZGV4fSBzdHlsZT17e2Rpc3BsYXk6IFwiYmxvY2tcIn19IG9uQ2xpY2s9eygpID0+IHNlbGVjdFJhY2UocmFjZS5pbmRleCl9PntyYWNlLm5hbWV9PC9hPlxuICAgIH0pfVxuICAgIGVsc2Uge1xuICAgICAgcmV0dXJuIDxkaXY+U29ycnksIGFuIGVycm9yIGhhcyBvY2N1cnJlZCE8L2Rpdj5cbiAgICB9XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxMYXlvdXQ+XG4gICAgICA8SGVhZD5cbiAgICAgICAgPHRpdGxlPkR1bmdlb25zIGFuZCBEcmFnb25zIEFQSSBCcm93c2VyPC90aXRsZT5cbiAgICAgICAgPG1ldGEgbmFtZT1cImRlc2NyaXB0aW9uXCIgY29udGVudD1cIkdlbmVyYXRlZCBieSBjcmVhdGUgbmV4dCBhcHBcIiAvPlxuICAgICAgICA8bGluayByZWw9XCJpY29uXCIgaHJlZj1cIi9mYXZpY29uLmljb1wiIC8+XG4gICAgICA8L0hlYWQ+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMubWFpbkNhcmR9PlxuICAgICAgICA8aDM+e3JhY2VOYW1lfTwvaDM+XG4gICAgICAgIDxwPjxiPkFsaWdubWVudDo8L2I+e1wiIFwifXthbGlnbm1lbnR9PC9wPlxuICAgICAgICA8cD48Yj5BZ2U6PC9iPntcIiBcIn17YWdlfTwvcD5cbiAgICAgICAgPHA+PGI+U2l6ZTo8L2I+e1wiIFwifXtzaXplfTwvcD5cbiAgICAgICAgPHA+PGI+TGFuZ3VhZ2VzOjwvYj57XCIgXCJ9e2xhbmd1YWdlfTwvcD5cbiAgICA8L2Rpdj5cbiAgICA8aDQgc3R5bGU9e3t0ZXh0QWxpZ246IFwiY2VudGVyXCJ9fT5Nb3JlIFJhY2VzPC9oND5cbiAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmxpbmtDb250YWluZXJ9PlxuICAgICAgPFJhY2VMaXN0IC8+XG4gICAgPC9kaXY+XG4gICAgXG4gICAgPC9MYXlvdXQ+XG4gIClcbn1cbiJdLCJuYW1lcyI6WyJIZWFkIiwic3R5bGVzIiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJMYXlvdXQiLCJheGlvcyIsIkhvbWUiLCJyYWNlcyIsInNldFJhY2VzIiwicmFjZU5hbWUiLCJzZXRSYWNlTmFtZSIsImFsaWdubWVudCIsInNldEFsaWdubWVudCIsImFnZSIsInNldEFnZSIsInNpemUiLCJzZXRTaXplIiwibGFuZ3VhZ2UiLCJzZXRMYW5ndWFnZSIsImdldCIsInRoZW4iLCJyZXMiLCJkYXRhIiwicmVzdWx0cyIsIm5hbWUiLCJzaXplX2Rlc2NyaXB0aW9uIiwibGFuZ3VhZ2VfZGVzYyIsInNlbGVjdFJhY2UiLCJlbCIsIlJhY2VMaXN0IiwidW5kZWZpbmVkIiwibWFwIiwicmFjZSIsImNhcmQiLCJkaXNwbGF5IiwiaW5kZXgiLCJtYWluQ2FyZCIsInRleHRBbGlnbiIsImxpbmtDb250YWluZXIiXSwic291cmNlUm9vdCI6IiJ9