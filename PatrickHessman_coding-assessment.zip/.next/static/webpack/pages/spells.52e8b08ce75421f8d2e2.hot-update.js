"use strict";
self["webpackHotUpdate_N_E"]("pages/spells",{

/***/ "./pages/spells.js":
/*!*************************!*\
  !*** ./pages/spells.js ***!
  \*************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ Home; }
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../styles/Home.module.css */ "./styles/Home.module.css");
/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/layout */ "./components/layout.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_4__);
/* module decorator */ module = __webpack_require__.hmd(module);



var _jsxFileName = "C:\\Users\\patri\\Documents\\webDevTraining\\1upHealth assessment\\lambda-take4\\pages\\spells.js",
    _s = $RefreshSig$();






function Home() {
  _s();

  var _this = this;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]),
      spells = _useState[0],
      setSpells = _useState[1];

  var _useState2 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(""),
      spellName = _useState2[0],
      setSpellName = _useState2[1];

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(""),
      desc = _useState3[0],
      setDesc = _useState3[1];

  var _useState4 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(""),
      higher = _useState4[0],
      setHigher = _useState4[1];

  var _useState5 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(""),
      range = _useState5[0],
      setRange = _useState5[1];

  var _useState6 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(""),
      level = _useState6[0],
      setLevel = _useState6[1];

  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(function () {
    axios__WEBPACK_IMPORTED_MODULE_4___default().get('https://8jxxb7mgec.execute-api.us-east-1.amazonaws.com/prod/spells').then(function (res) {
      setSpells(res.data[0].results);
      setSpellName(res.data[1].name);
      setDesc(res.data[1].desc);
      setHigher(res.data[1].higher_level);
      setRange(res.data[1].range);
      setLevel(res.data[1].level);
    });
  }, []);

  var selectSpell = function selectSpell(el) {
    axios__WEBPACK_IMPORTED_MODULE_4___default().get("https://8jxxb7mgec.execute-api.us-east-1.amazonaws.com/prod/spells/".concat(el)).then(function (res) {
      setSpellName(res.data.name);
      setDesc(res.data.desc);
      setHigher(res.data.higher_level);
      setRange(res.data.range);
      setLevel(res.data.level);
    });
  };

  var HigherLevel = function HigherLevel() {
    if (higher === undefined) {
      return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}, void 0, false);
    } else {
      return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("b", {
          children: "At Higher Levels:"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 43,
          columnNumber: 19
        }, _this), " ", higher]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 43,
        columnNumber: 16
      }, _this);
    }
  };

  var SpellList = function SpellList() {
    if (spells !== undefined) {
      spells.map(function (spell) {
        return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
          className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_5___default().card),
          style: {
            display: "block"
          },
          onClick: function onClick() {
            return selectSpell(spell.index);
          },
          children: spell.name
        }, spell.index, false, {
          fileName: _jsxFileName,
          lineNumber: 50,
          columnNumber: 14
        }, _this);
      });
    } else {
      return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        children: "Sorry, an error has occurred!"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 54,
        columnNumber: 12
      }, _this);
    }
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_layout__WEBPACK_IMPORTED_MODULE_3__.default, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("title", {
        children: "Dungeons and Dragons API Browser"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 61,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("meta", {
        name: "description",
        content: "Generated by create next app"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 62,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("link", {
        rel: "icon",
        href: "/favicon.ico"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 63,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 60,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_5___default().mainCard),
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h3", {
        children: spellName
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 66,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("em", {
          children: desc
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 67,
          columnNumber: 12
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 67,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("b", {
          children: "Level:"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 68,
          columnNumber: 12
        }, this), " ", level]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 68,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("b", {
          children: "Range:"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 69,
          columnNumber: 12
        }, this), " ", range]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 69,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(HigherLevel, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 70,
        columnNumber: 10
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 65,
      columnNumber: 9
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h4", {
      style: {
        textAlign: "center"
      },
      children: "More Spells"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 73,
      columnNumber: 5
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_5___default().linkContainer),
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(SpellList, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 75,
        columnNumber: 7
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 74,
      columnNumber: 5
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 59,
    columnNumber: 5
  }, this);
}

_s(Home, "gQDoWJZXeftlTIih7maZR5uDr+8=");

_c = Home;

var _c;

$RefreshReg$(_c, "Home");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvc3BlbGxzLjUyZThiMDhjZTc1NDIxZjhkMmUyLmhvdC11cGRhdGUuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFFZSxTQUFTTSxJQUFULEdBQWdCO0FBQUE7O0FBQUE7O0FBQUEsa0JBRUZKLCtDQUFRLENBQUMsRUFBRCxDQUZOO0FBQUEsTUFFdEJLLE1BRnNCO0FBQUEsTUFFZkMsU0FGZTs7QUFBQSxtQkFHTU4sK0NBQVEsQ0FBQyxFQUFELENBSGQ7QUFBQSxNQUd0Qk8sU0FIc0I7QUFBQSxNQUdYQyxZQUhXOztBQUFBLG1CQUlKUiwrQ0FBUSxDQUFDLEVBQUQsQ0FKSjtBQUFBLE1BSXRCUyxJQUpzQjtBQUFBLE1BSWhCQyxPQUpnQjs7QUFBQSxtQkFLQVYsK0NBQVEsQ0FBQyxFQUFELENBTFI7QUFBQSxNQUt0QlcsTUFMc0I7QUFBQSxNQUtkQyxTQUxjOztBQUFBLG1CQU1GWiwrQ0FBUSxDQUFDLEVBQUQsQ0FOTjtBQUFBLE1BTXRCYSxLQU5zQjtBQUFBLE1BTWZDLFFBTmU7O0FBQUEsbUJBT0ZkLCtDQUFRLENBQUMsRUFBRCxDQVBOO0FBQUEsTUFPdEJlLEtBUHNCO0FBQUEsTUFPZkMsUUFQZTs7QUFTN0JmLEVBQUFBLGdEQUFTLENBQUMsWUFBTTtBQUNaRSxJQUFBQSxnREFBQSxDQUFVLG9FQUFWLEVBQWdGZSxJQUFoRixDQUFxRixVQUFBQyxHQUFHLEVBQUk7QUFDNUZiLE1BQUFBLFNBQVMsQ0FBQ2EsR0FBRyxDQUFDQyxJQUFKLENBQVMsQ0FBVCxFQUFZQyxPQUFiLENBQVQ7QUFDQWIsTUFBQUEsWUFBWSxDQUFDVyxHQUFHLENBQUNDLElBQUosQ0FBUyxDQUFULEVBQVlFLElBQWIsQ0FBWjtBQUNBWixNQUFBQSxPQUFPLENBQUNTLEdBQUcsQ0FBQ0MsSUFBSixDQUFTLENBQVQsRUFBWVgsSUFBYixDQUFQO0FBQ0FHLE1BQUFBLFNBQVMsQ0FBQ08sR0FBRyxDQUFDQyxJQUFKLENBQVMsQ0FBVCxFQUFZRyxZQUFiLENBQVQ7QUFDQVQsTUFBQUEsUUFBUSxDQUFDSyxHQUFHLENBQUNDLElBQUosQ0FBUyxDQUFULEVBQVlQLEtBQWIsQ0FBUjtBQUNBRyxNQUFBQSxRQUFRLENBQUNHLEdBQUcsQ0FBQ0MsSUFBSixDQUFTLENBQVQsRUFBWUwsS0FBYixDQUFSO0FBQ0QsS0FQQztBQVFILEdBVFEsRUFTTixFQVRNLENBQVQ7O0FBV0EsTUFBTVMsV0FBVyxHQUFHLFNBQWRBLFdBQWMsQ0FBQ0MsRUFBRCxFQUFRO0FBQ3hCdEIsSUFBQUEsZ0RBQUEsOEVBQWdGc0IsRUFBaEYsR0FBc0ZQLElBQXRGLENBQTJGLFVBQUFDLEdBQUcsRUFBSTtBQUNoR1gsTUFBQUEsWUFBWSxDQUFDVyxHQUFHLENBQUNDLElBQUosQ0FBU0UsSUFBVixDQUFaO0FBQ0FaLE1BQUFBLE9BQU8sQ0FBQ1MsR0FBRyxDQUFDQyxJQUFKLENBQVNYLElBQVYsQ0FBUDtBQUNBRyxNQUFBQSxTQUFTLENBQUNPLEdBQUcsQ0FBQ0MsSUFBSixDQUFTRyxZQUFWLENBQVQ7QUFDQVQsTUFBQUEsUUFBUSxDQUFDSyxHQUFHLENBQUNDLElBQUosQ0FBU1AsS0FBVixDQUFSO0FBQ0FHLE1BQUFBLFFBQVEsQ0FBQ0csR0FBRyxDQUFDQyxJQUFKLENBQVNMLEtBQVYsQ0FBUjtBQUNILEtBTkM7QUFPSCxHQVJEOztBQVVBLE1BQU1XLFdBQVcsR0FBRyxTQUFkQSxXQUFjLEdBQU07QUFDdEIsUUFBSWYsTUFBTSxLQUFLZ0IsU0FBZixFQUEwQjtBQUN0QiwwQkFBTyw2SUFBUDtBQUNILEtBRkQsTUFHSztBQUNILDBCQUFPO0FBQUEsZ0NBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQUgsRUFBNEIsR0FBNUIsRUFBaUNoQixNQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBUDtBQUNEO0FBQ0osR0FQRDs7QUFTQSxNQUFNaUIsU0FBUyxHQUFHLFNBQVpBLFNBQVksR0FBTTtBQUN0QixRQUFJdkIsTUFBTSxLQUFLc0IsU0FBZixFQUEwQjtBQUN4QnRCLE1BQUFBLE1BQU0sQ0FBQ3dCLEdBQVAsQ0FBVyxVQUFBQyxLQUFLLEVBQUk7QUFDcEIsNEJBQU87QUFBRyxtQkFBUyxFQUFFL0IscUVBQWQ7QUFBNkMsZUFBSyxFQUFFO0FBQUNpQyxZQUFBQSxPQUFPLEVBQUU7QUFBVixXQUFwRDtBQUF3RSxpQkFBTyxFQUFFO0FBQUEsbUJBQU1SLFdBQVcsQ0FBQ00sS0FBSyxDQUFDRyxLQUFQLENBQWpCO0FBQUEsV0FBakY7QUFBQSxvQkFBa0hILEtBQUssQ0FBQ1I7QUFBeEgsV0FBZ0NRLEtBQUssQ0FBQ0csS0FBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBUDtBQUNELE9BRkM7QUFHSCxLQUpDLE1BS0c7QUFDSCwwQkFBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFQO0FBQ0Q7QUFDQSxHQVREOztBQVdBLHNCQUNFLDhEQUFDLHVEQUFEO0FBQUEsNEJBQ0UsOERBQUMsa0RBQUQ7QUFBQSw4QkFDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGLGVBRUU7QUFBTSxZQUFJLEVBQUMsYUFBWDtBQUF5QixlQUFPLEVBQUM7QUFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUZGLGVBR0U7QUFBTSxXQUFHLEVBQUMsTUFBVjtBQUFpQixZQUFJLEVBQUM7QUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGLGVBTUk7QUFBSyxlQUFTLEVBQUVsQyx5RUFBaEI7QUFBQSw4QkFDQTtBQUFBLGtCQUFLUTtBQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FEQSxlQUVBO0FBQUEsK0JBQUc7QUFBQSxvQkFBS0U7QUFBTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUZBLGVBR0E7QUFBQSxnQ0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFBSCxFQUFpQixHQUFqQixFQUFzQk0sS0FBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSEEsZUFJQTtBQUFBLGdDQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUFILEVBQWlCLEdBQWpCLEVBQXNCRixLQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FKQSxlQUtDLDhEQUFDLFdBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU5KLGVBY0E7QUFBSSxXQUFLLEVBQUU7QUFBQ3NCLFFBQUFBLFNBQVMsRUFBRTtBQUFaLE9BQVg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFkQSxlQWVBO0FBQUssZUFBUyxFQUFFcEMsOEVBQWhCO0FBQUEsNkJBQ0UsOERBQUMsU0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWZBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBc0JEOztHQXhFdUJLOztLQUFBQSIsInNvdXJjZXMiOlsid2VicGFjazovL19OX0UvLi9wYWdlcy9zcGVsbHMuanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IEhlYWQgZnJvbSAnbmV4dC9oZWFkJ1xyXG5pbXBvcnQgc3R5bGVzIGZyb20gJy4uL3N0eWxlcy9Ib21lLm1vZHVsZS5jc3MnXHJcbmltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XHJcblxyXG5pbXBvcnQgTGF5b3V0IGZyb20gJy4uL2NvbXBvbmVudHMvbGF5b3V0JztcclxuaW1wb3J0IGF4aW9zIGZyb20gJ2F4aW9zJztcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEhvbWUoKSB7XHJcblxyXG4gIGNvbnN0IFtzcGVsbHMsc2V0U3BlbGxzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc3BlbGxOYW1lLCBzZXRTcGVsbE5hbWVdICA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtkZXNjLCBzZXREZXNjXSAgPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbaGlnaGVyLCBzZXRIaWdoZXJdICA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtyYW5nZSwgc2V0UmFuZ2VdICA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtsZXZlbCwgc2V0TGV2ZWxdICA9IHVzZVN0YXRlKFwiXCIpO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgICBheGlvcy5nZXQoJ2h0dHBzOi8vOGp4eGI3bWdlYy5leGVjdXRlLWFwaS51cy1lYXN0LTEuYW1hem9uYXdzLmNvbS9wcm9kL3NwZWxscycpLnRoZW4ocmVzID0+IHtcclxuICAgICAgc2V0U3BlbGxzKHJlcy5kYXRhWzBdLnJlc3VsdHMpO1xyXG4gICAgICBzZXRTcGVsbE5hbWUocmVzLmRhdGFbMV0ubmFtZSk7XHJcbiAgICAgIHNldERlc2MocmVzLmRhdGFbMV0uZGVzYyk7XHJcbiAgICAgIHNldEhpZ2hlcihyZXMuZGF0YVsxXS5oaWdoZXJfbGV2ZWwpO1xyXG4gICAgICBzZXRSYW5nZShyZXMuZGF0YVsxXS5yYW5nZSk7XHJcbiAgICAgIHNldExldmVsKHJlcy5kYXRhWzFdLmxldmVsKTtcclxuICAgIH0pXHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBzZWxlY3RTcGVsbCA9IChlbCkgPT4ge1xyXG4gICAgICBheGlvcy5nZXQoYGh0dHBzOi8vOGp4eGI3bWdlYy5leGVjdXRlLWFwaS51cy1lYXN0LTEuYW1hem9uYXdzLmNvbS9wcm9kL3NwZWxscy8ke2VsfWApLnRoZW4ocmVzID0+IHtcclxuICAgICAgICBzZXRTcGVsbE5hbWUocmVzLmRhdGEubmFtZSk7XHJcbiAgICAgICAgc2V0RGVzYyhyZXMuZGF0YS5kZXNjKTtcclxuICAgICAgICBzZXRIaWdoZXIocmVzLmRhdGEuaGlnaGVyX2xldmVsKTtcclxuICAgICAgICBzZXRSYW5nZShyZXMuZGF0YS5yYW5nZSk7XHJcbiAgICAgICAgc2V0TGV2ZWwocmVzLmRhdGEubGV2ZWwpO1xyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBjb25zdCBIaWdoZXJMZXZlbCA9ICgpID0+IHtcclxuICAgICAgaWYgKGhpZ2hlciA9PT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICByZXR1cm4gPD48Lz5cclxuICAgICAgfVxyXG4gICAgICBlbHNlIHtcclxuICAgICAgICByZXR1cm4gPHA+PGI+QXQgSGlnaGVyIExldmVsczo8L2I+e1wiIFwifXtoaWdoZXJ9PC9wPjtcclxuICAgICAgfVxyXG4gIH1cclxuXHJcbiAgY29uc3QgU3BlbGxMaXN0ID0gKCkgPT4ge1xyXG4gICAgaWYgKHNwZWxscyAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgIHNwZWxscy5tYXAoc3BlbGwgPT4ge1xyXG4gICAgICByZXR1cm4gPGEgY2xhc3NOYW1lPXtzdHlsZXMuY2FyZH0ga2V5PXtzcGVsbC5pbmRleH0gc3R5bGU9e3tkaXNwbGF5OiBcImJsb2NrXCJ9fSBvbkNsaWNrPXsoKSA9PiBzZWxlY3RTcGVsbChzcGVsbC5pbmRleCl9PntzcGVsbC5uYW1lfTwvYT5cclxuICAgIH0pXHJcbiAgfVxyXG4gIGVsc2Uge1xyXG4gICAgcmV0dXJuIDxkaXY+U29ycnksIGFuIGVycm9yIGhhcyBvY2N1cnJlZCE8L2Rpdj5cclxuICB9XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPExheW91dD5cclxuICAgICAgPEhlYWQ+XHJcbiAgICAgICAgPHRpdGxlPkR1bmdlb25zIGFuZCBEcmFnb25zIEFQSSBCcm93c2VyPC90aXRsZT5cclxuICAgICAgICA8bWV0YSBuYW1lPVwiZGVzY3JpcHRpb25cIiBjb250ZW50PVwiR2VuZXJhdGVkIGJ5IGNyZWF0ZSBuZXh0IGFwcFwiIC8+XHJcbiAgICAgICAgPGxpbmsgcmVsPVwiaWNvblwiIGhyZWY9XCIvZmF2aWNvbi5pY29cIiAvPlxyXG4gICAgICA8L0hlYWQ+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5tYWluQ2FyZH0+XHJcbiAgICAgICAgPGgzPntzcGVsbE5hbWV9PC9oMz5cclxuICAgICAgICA8cD48ZW0+e2Rlc2N9PC9lbT48L3A+XHJcbiAgICAgICAgPHA+PGI+TGV2ZWw6PC9iPntcIiBcIn17bGV2ZWx9PC9wPlxyXG4gICAgICAgIDxwPjxiPlJhbmdlOjwvYj57XCIgXCJ9e3JhbmdlfTwvcD5cclxuICAgICAgICB7PEhpZ2hlckxldmVsIC8+fVxyXG4gICAgICAgIFxyXG4gICAgPC9kaXY+XHJcbiAgICA8aDQgc3R5bGU9e3t0ZXh0QWxpZ246IFwiY2VudGVyXCJ9fT5Nb3JlIFNwZWxsczwvaDQ+XHJcbiAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmxpbmtDb250YWluZXJ9PlxyXG4gICAgICA8U3BlbGxMaXN0IC8+XHJcbiAgICA8L2Rpdj5cclxuICAgIFxyXG4gICAgPC9MYXlvdXQ+XHJcbiAgKVxyXG59XHJcbiJdLCJuYW1lcyI6WyJIZWFkIiwic3R5bGVzIiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJMYXlvdXQiLCJheGlvcyIsIkhvbWUiLCJzcGVsbHMiLCJzZXRTcGVsbHMiLCJzcGVsbE5hbWUiLCJzZXRTcGVsbE5hbWUiLCJkZXNjIiwic2V0RGVzYyIsImhpZ2hlciIsInNldEhpZ2hlciIsInJhbmdlIiwic2V0UmFuZ2UiLCJsZXZlbCIsInNldExldmVsIiwiZ2V0IiwidGhlbiIsInJlcyIsImRhdGEiLCJyZXN1bHRzIiwibmFtZSIsImhpZ2hlcl9sZXZlbCIsInNlbGVjdFNwZWxsIiwiZWwiLCJIaWdoZXJMZXZlbCIsInVuZGVmaW5lZCIsIlNwZWxsTGlzdCIsIm1hcCIsInNwZWxsIiwiY2FyZCIsImRpc3BsYXkiLCJpbmRleCIsIm1haW5DYXJkIiwidGV4dEFsaWduIiwibGlua0NvbnRhaW5lciJdLCJzb3VyY2VSb290IjoiIn0=