"use strict";
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ Home; }
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../styles/Home.module.css */ "./styles/Home.module.css");
/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/layout */ "./components/layout.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_4__);
/* module decorator */ module = __webpack_require__.hmd(module);


var _jsxFileName = "C:\\Users\\patri\\Documents\\webDevTraining\\1upHealth assessment\\lambda-take4\\pages\\index.js",
    _s = $RefreshSig$();

// comment





function Home() {
  _s();

  var _this = this;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]),
      races = _useState[0],
      setRaces = _useState[1];

  var _useState2 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(""),
      raceName = _useState2[0],
      setRaceName = _useState2[1];

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(""),
      alignment = _useState3[0],
      setAlignment = _useState3[1];

  var _useState4 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(""),
      age = _useState4[0],
      setAge = _useState4[1];

  var _useState5 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(""),
      size = _useState5[0],
      setSize = _useState5[1];

  var _useState6 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(""),
      language = _useState6[0],
      setLanguage = _useState6[1];

  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(function () {
    axios__WEBPACK_IMPORTED_MODULE_4___default().get('https://8jxxb7mgec.execute-api.us-east-1.amazonaws.com/prod/races/').then(function (res) {
      setRaces(res.data[0].results);
      setAlignment(res.data[1].alignment);
      setRaceName(res.data[1].name);
      setAge(res.data[1].age);
      setSize(res.data[1].size_description);
      setLanguage(res.data[1].language_desc);
    });
  }, []);

  var selectRace = function selectRace(el) {
    axios__WEBPACK_IMPORTED_MODULE_4___default().get("https://8jxxb7mgec.execute-api.us-east-1.amazonaws.com/prod/races/".concat(el)).then(function (res) {
      setAlignment(res.data.alignment);
      setRaceName(res.data.name);
      setAge(res.data.age);
      setSize(res.data.size_description);
      setLanguage(res.data.language_desc);
    });
  };

  var RaceList = function RaceList() {
    if (races !== undefined) {
      return races.map(function (race) {
        return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
          className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_5___default().card),
          style: {
            display: "block"
          },
          onClick: function onClick() {
            return selectRace(race.index);
          },
          children: race.name
        }, race.index, false, {
          fileName: _jsxFileName,
          lineNumber: 42,
          columnNumber: 14
        }, _this);
      });
    } else {
      return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        children: "Sorry, an error has occurred!"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 45,
        columnNumber: 14
      }, _this);
    }
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_layout__WEBPACK_IMPORTED_MODULE_3__.default, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("title", {
        children: "Dungeons and Dragons API Browser"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 52,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("meta", {
        name: "description",
        content: "Generated by create next app"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 53,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("link", {
        rel: "icon",
        href: "/favicon.ico"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 54,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 51,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_5___default().mainCard),
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h3", {
        children: raceName
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 57,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("b", {
          children: "Alignment:"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 58,
          columnNumber: 12
        }, this), " ", alignment]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 58,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("b", {
          children: "Age:"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 59,
          columnNumber: 12
        }, this), " ", age]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 59,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("b", {
          children: "Size:"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 60,
          columnNumber: 12
        }, this), " ", size]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 60,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("b", {
          children: "Languages:"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 61,
          columnNumber: 12
        }, this), " ", language]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 61,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 56,
      columnNumber: 9
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h4", {
      style: {
        textAlign: "center"
      },
      children: "More Races"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 63,
      columnNumber: 5
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_5___default().linkContainer),
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(RaceList, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 65,
        columnNumber: 7
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 64,
      columnNumber: 5
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 50,
    columnNumber: 5
  }, this);
}

_s(Home, "yOr3KbE7Dn12mGR6hyuU2ePBr0A=");

_c = Home;

var _c;

$RefreshReg$(_c, "Home");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguMDA5MjNiZDVkZGNlNTY0OTAzNDUuaG90LXVwZGF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFFZSxTQUFTTSxJQUFULEdBQWdCO0FBQUE7O0FBQUE7O0FBQUEsa0JBRUpKLCtDQUFRLENBQUMsRUFBRCxDQUZKO0FBQUEsTUFFdEJLLEtBRnNCO0FBQUEsTUFFaEJDLFFBRmdCOztBQUFBLG1CQUdJTiwrQ0FBUSxDQUFDLEVBQUQsQ0FIWjtBQUFBLE1BR3RCTyxRQUhzQjtBQUFBLE1BR1pDLFdBSFk7O0FBQUEsbUJBSU1SLCtDQUFRLENBQUMsRUFBRCxDQUpkO0FBQUEsTUFJdEJTLFNBSnNCO0FBQUEsTUFJWEMsWUFKVzs7QUFBQSxtQkFLTlYsK0NBQVEsQ0FBQyxFQUFELENBTEY7QUFBQSxNQUt0QlcsR0FMc0I7QUFBQSxNQUtqQkMsTUFMaUI7O0FBQUEsbUJBTUpaLCtDQUFRLENBQUMsRUFBRCxDQU5KO0FBQUEsTUFNdEJhLElBTnNCO0FBQUEsTUFNaEJDLE9BTmdCOztBQUFBLG1CQU9JZCwrQ0FBUSxDQUFDLEVBQUQsQ0FQWjtBQUFBLE1BT3RCZSxRQVBzQjtBQUFBLE1BT1pDLFdBUFk7O0FBUzdCZixFQUFBQSxnREFBUyxDQUFDLFlBQU07QUFDWkUsSUFBQUEsZ0RBQUEsQ0FBVSxvRUFBVixFQUFnRmUsSUFBaEYsQ0FBcUYsVUFBQUMsR0FBRyxFQUFJO0FBQzVGYixNQUFBQSxRQUFRLENBQUNhLEdBQUcsQ0FBQ0MsSUFBSixDQUFTLENBQVQsRUFBWUMsT0FBYixDQUFSO0FBQ0FYLE1BQUFBLFlBQVksQ0FBQ1MsR0FBRyxDQUFDQyxJQUFKLENBQVMsQ0FBVCxFQUFZWCxTQUFiLENBQVo7QUFDQUQsTUFBQUEsV0FBVyxDQUFDVyxHQUFHLENBQUNDLElBQUosQ0FBUyxDQUFULEVBQVlFLElBQWIsQ0FBWDtBQUNBVixNQUFBQSxNQUFNLENBQUNPLEdBQUcsQ0FBQ0MsSUFBSixDQUFTLENBQVQsRUFBWVQsR0FBYixDQUFOO0FBQ0FHLE1BQUFBLE9BQU8sQ0FBQ0ssR0FBRyxDQUFDQyxJQUFKLENBQVMsQ0FBVCxFQUFZRyxnQkFBYixDQUFQO0FBQ0FQLE1BQUFBLFdBQVcsQ0FBQ0csR0FBRyxDQUFDQyxJQUFKLENBQVMsQ0FBVCxFQUFZSSxhQUFiLENBQVg7QUFDRCxLQVBDO0FBUUgsR0FUUSxFQVNOLEVBVE0sQ0FBVDs7QUFXQSxNQUFNQyxVQUFVLEdBQUcsU0FBYkEsVUFBYSxDQUFDQyxFQUFELEVBQVE7QUFDdkJ2QixJQUFBQSxnREFBQSw2RUFBK0V1QixFQUEvRSxHQUFxRlIsSUFBckYsQ0FBMEYsVUFBQUMsR0FBRyxFQUFJO0FBQ2pHVCxNQUFBQSxZQUFZLENBQUNTLEdBQUcsQ0FBQ0MsSUFBSixDQUFTWCxTQUFWLENBQVo7QUFDQUQsTUFBQUEsV0FBVyxDQUFDVyxHQUFHLENBQUNDLElBQUosQ0FBU0UsSUFBVixDQUFYO0FBQ0FWLE1BQUFBLE1BQU0sQ0FBQ08sR0FBRyxDQUFDQyxJQUFKLENBQVNULEdBQVYsQ0FBTjtBQUNBRyxNQUFBQSxPQUFPLENBQUNLLEdBQUcsQ0FBQ0MsSUFBSixDQUFTRyxnQkFBVixDQUFQO0FBQ0FQLE1BQUFBLFdBQVcsQ0FBQ0csR0FBRyxDQUFDQyxJQUFKLENBQVNJLGFBQVYsQ0FBWDtBQUNELEtBTkM7QUFPSCxHQVJEOztBQVVBLE1BQU1HLFFBQVEsR0FBRyxTQUFYQSxRQUFXLEdBQU07QUFDckIsUUFBSXRCLEtBQUssS0FBS3VCLFNBQWQsRUFBeUI7QUFDdkIsYUFBT3ZCLEtBQUssQ0FBQ3dCLEdBQU4sQ0FBVSxVQUFBQyxJQUFJLEVBQUk7QUFDekIsNEJBQU87QUFBRyxtQkFBUyxFQUFFL0IscUVBQWQ7QUFBNEMsZUFBSyxFQUFFO0FBQUNpQyxZQUFBQSxPQUFPLEVBQUU7QUFBVixXQUFuRDtBQUF1RSxpQkFBTyxFQUFFO0FBQUEsbUJBQU1QLFVBQVUsQ0FBQ0ssSUFBSSxDQUFDRyxLQUFOLENBQWhCO0FBQUEsV0FBaEY7QUFBQSxvQkFBK0dILElBQUksQ0FBQ1I7QUFBcEgsV0FBZ0NRLElBQUksQ0FBQ0csS0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBUDtBQUNELE9BRlEsQ0FBUDtBQUVDLEtBSEgsTUFJSztBQUNILDBCQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVA7QUFDRDtBQUNGLEdBUkQ7O0FBVUEsc0JBQ0UsOERBQUMsdURBQUQ7QUFBQSw0QkFDRSw4REFBQyxrREFBRDtBQUFBLDhCQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUFFRTtBQUFNLFlBQUksRUFBQyxhQUFYO0FBQXlCLGVBQU8sRUFBQztBQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRkYsZUFHRTtBQUFNLFdBQUcsRUFBQyxNQUFWO0FBQWlCLFlBQUksRUFBQztBQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREYsZUFNSTtBQUFLLGVBQVMsRUFBRWxDLHlFQUFoQjtBQUFBLDhCQUNBO0FBQUEsa0JBQUtRO0FBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURBLGVBRUE7QUFBQSxnQ0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFBSCxFQUFxQixHQUFyQixFQUEwQkUsU0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRkEsZUFHQTtBQUFBLGdDQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUFILEVBQWUsR0FBZixFQUFvQkUsR0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSEEsZUFJQTtBQUFBLGdDQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUFILEVBQWdCLEdBQWhCLEVBQXFCRSxJQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FKQSxlQUtBO0FBQUEsZ0NBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQUgsRUFBcUIsR0FBckIsRUFBMEJFLFFBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUxBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU5KLGVBYUE7QUFBSSxXQUFLLEVBQUU7QUFBQ29CLFFBQUFBLFNBQVMsRUFBRTtBQUFaLE9BQVg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFiQSxlQWNBO0FBQUssZUFBUyxFQUFFcEMsOEVBQWhCO0FBQUEsNkJBQ0UsOERBQUMsUUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWRBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBcUJEOztHQTdEdUJLOztLQUFBQSIsInNvdXJjZXMiOlsid2VicGFjazovL19OX0UvLi9wYWdlcy9pbmRleC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBjb21tZW50XG5pbXBvcnQgSGVhZCBmcm9tICduZXh0L2hlYWQnXG5pbXBvcnQgc3R5bGVzIGZyb20gJy4uL3N0eWxlcy9Ib21lLm1vZHVsZS5jc3MnXG5pbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuXG5pbXBvcnQgTGF5b3V0IGZyb20gJy4uL2NvbXBvbmVudHMvbGF5b3V0JztcbmltcG9ydCBheGlvcyBmcm9tICdheGlvcyc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEhvbWUoKSB7XG5cbiAgY29uc3QgW3JhY2VzLHNldFJhY2VzXSA9IHVzZVN0YXRlKFtdKTtcbiAgY29uc3QgW3JhY2VOYW1lLCBzZXRSYWNlTmFtZV0gID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFthbGlnbm1lbnQsIHNldEFsaWdubWVudF0gID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFthZ2UsIHNldEFnZV0gID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtzaXplLCBzZXRTaXplXSAgPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2xhbmd1YWdlLCBzZXRMYW5ndWFnZV0gID0gdXNlU3RhdGUoXCJcIik7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgIGF4aW9zLmdldCgnaHR0cHM6Ly84anh4YjdtZ2VjLmV4ZWN1dGUtYXBpLnVzLWVhc3QtMS5hbWF6b25hd3MuY29tL3Byb2QvcmFjZXMvJykudGhlbihyZXMgPT4ge1xuICAgICAgc2V0UmFjZXMocmVzLmRhdGFbMF0ucmVzdWx0cyk7XG4gICAgICBzZXRBbGlnbm1lbnQocmVzLmRhdGFbMV0uYWxpZ25tZW50KTtcbiAgICAgIHNldFJhY2VOYW1lKHJlcy5kYXRhWzFdLm5hbWUpO1xuICAgICAgc2V0QWdlKHJlcy5kYXRhWzFdLmFnZSk7XG4gICAgICBzZXRTaXplKHJlcy5kYXRhWzFdLnNpemVfZGVzY3JpcHRpb24pO1xuICAgICAgc2V0TGFuZ3VhZ2UocmVzLmRhdGFbMV0ubGFuZ3VhZ2VfZGVzYyk7XG4gICAgfSlcbiAgfSwgW10pO1xuXG4gIGNvbnN0IHNlbGVjdFJhY2UgPSAoZWwpID0+IHtcbiAgICAgIGF4aW9zLmdldChgaHR0cHM6Ly84anh4YjdtZ2VjLmV4ZWN1dGUtYXBpLnVzLWVhc3QtMS5hbWF6b25hd3MuY29tL3Byb2QvcmFjZXMvJHtlbH1gKS50aGVuKHJlcyA9PiB7XG4gICAgICBzZXRBbGlnbm1lbnQocmVzLmRhdGEuYWxpZ25tZW50KTtcbiAgICAgIHNldFJhY2VOYW1lKHJlcy5kYXRhLm5hbWUpO1xuICAgICAgc2V0QWdlKHJlcy5kYXRhLmFnZSk7XG4gICAgICBzZXRTaXplKHJlcy5kYXRhLnNpemVfZGVzY3JpcHRpb24pO1xuICAgICAgc2V0TGFuZ3VhZ2UocmVzLmRhdGEubGFuZ3VhZ2VfZGVzYyk7XG4gICAgfSk7XG4gIH1cblxuICBjb25zdCBSYWNlTGlzdCA9ICgpID0+IHtcbiAgICBpZiAocmFjZXMgIT09IHVuZGVmaW5lZCkge1xuICAgICAgcmV0dXJuIHJhY2VzLm1hcChyYWNlID0+IHtcbiAgICAgIHJldHVybiA8YSBjbGFzc05hbWU9e3N0eWxlcy5jYXJkfSBrZXk9e3JhY2UuaW5kZXh9IHN0eWxlPXt7ZGlzcGxheTogXCJibG9ja1wifX0gb25DbGljaz17KCkgPT4gc2VsZWN0UmFjZShyYWNlLmluZGV4KX0+e3JhY2UubmFtZX08L2E+XG4gICAgfSl9XG4gICAgZWxzZSB7XG4gICAgICByZXR1cm4gPGRpdj5Tb3JyeSwgYW4gZXJyb3IgaGFzIG9jY3VycmVkITwvZGl2PlxuICAgIH1cbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPExheW91dD5cbiAgICAgIDxIZWFkPlxuICAgICAgICA8dGl0bGU+RHVuZ2VvbnMgYW5kIERyYWdvbnMgQVBJIEJyb3dzZXI8L3RpdGxlPlxuICAgICAgICA8bWV0YSBuYW1lPVwiZGVzY3JpcHRpb25cIiBjb250ZW50PVwiR2VuZXJhdGVkIGJ5IGNyZWF0ZSBuZXh0IGFwcFwiIC8+XG4gICAgICAgIDxsaW5rIHJlbD1cImljb25cIiBocmVmPVwiL2Zhdmljb24uaWNvXCIgLz5cbiAgICAgIDwvSGVhZD5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5tYWluQ2FyZH0+XG4gICAgICAgIDxoMz57cmFjZU5hbWV9PC9oMz5cbiAgICAgICAgPHA+PGI+QWxpZ25tZW50OjwvYj57XCIgXCJ9e2FsaWdubWVudH08L3A+XG4gICAgICAgIDxwPjxiPkFnZTo8L2I+e1wiIFwifXthZ2V9PC9wPlxuICAgICAgICA8cD48Yj5TaXplOjwvYj57XCIgXCJ9e3NpemV9PC9wPlxuICAgICAgICA8cD48Yj5MYW5ndWFnZXM6PC9iPntcIiBcIn17bGFuZ3VhZ2V9PC9wPlxuICAgIDwvZGl2PlxuICAgIDxoNCBzdHlsZT17e3RleHRBbGlnbjogXCJjZW50ZXJcIn19Pk1vcmUgUmFjZXM8L2g0PlxuICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMubGlua0NvbnRhaW5lcn0+XG4gICAgICA8UmFjZUxpc3QgLz5cbiAgICA8L2Rpdj5cbiAgICBcbiAgICA8L0xheW91dD5cbiAgKVxufVxuIl0sIm5hbWVzIjpbIkhlYWQiLCJzdHlsZXMiLCJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsIkxheW91dCIsImF4aW9zIiwiSG9tZSIsInJhY2VzIiwic2V0UmFjZXMiLCJyYWNlTmFtZSIsInNldFJhY2VOYW1lIiwiYWxpZ25tZW50Iiwic2V0QWxpZ25tZW50IiwiYWdlIiwic2V0QWdlIiwic2l6ZSIsInNldFNpemUiLCJsYW5ndWFnZSIsInNldExhbmd1YWdlIiwiZ2V0IiwidGhlbiIsInJlcyIsImRhdGEiLCJyZXN1bHRzIiwibmFtZSIsInNpemVfZGVzY3JpcHRpb24iLCJsYW5ndWFnZV9kZXNjIiwic2VsZWN0UmFjZSIsImVsIiwiUmFjZUxpc3QiLCJ1bmRlZmluZWQiLCJtYXAiLCJyYWNlIiwiY2FyZCIsImRpc3BsYXkiLCJpbmRleCIsIm1haW5DYXJkIiwidGV4dEFsaWduIiwibGlua0NvbnRhaW5lciJdLCJzb3VyY2VSb290IjoiIn0=