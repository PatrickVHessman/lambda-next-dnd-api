"use strict";
self["webpackHotUpdate_N_E"]("pages/spells",{

/***/ "./pages/spells.js":
/*!*************************!*\
  !*** ./pages/spells.js ***!
  \*************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ Home; }
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../styles/Home.module.css */ "./styles/Home.module.css");
/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/layout */ "./components/layout.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_4__);
/* module decorator */ module = __webpack_require__.hmd(module);



var _jsxFileName = "C:\\Users\\patri\\Documents\\webDevTraining\\1upHealth assessment\\lambda-take4\\pages\\spells.js",
    _s = $RefreshSig$();






function Home() {
  _s();

  var _this = this;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]),
      spells = _useState[0],
      setSpells = _useState[1];

  var _useState2 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(""),
      spellName = _useState2[0],
      setSpellName = _useState2[1];

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(""),
      desc = _useState3[0],
      setDesc = _useState3[1];

  var _useState4 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(""),
      higher = _useState4[0],
      setHigher = _useState4[1];

  var _useState5 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(""),
      range = _useState5[0],
      setRange = _useState5[1];

  var _useState6 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(""),
      level = _useState6[0],
      setLevel = _useState6[1];

  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(function () {
    axios__WEBPACK_IMPORTED_MODULE_4___default().get('').then(function (res) {
      setSpells(res.data[0].results);
      setSpellName(res.data[1].name);
      setDesc(res.data[1].desc);
      setHigher(res.data[1].higher_level);
      setRange(res.data[1].range);
      setLevel(res.data[1].level);
    });
  }, []);

  var selectSpell = function selectSpell(el) {
    axios__WEBPACK_IMPORTED_MODULE_4___default().get("https://8jxxb7mgec.execute-api.us-east-1.amazonaws.com/prod/spells/".concat(el)).then(function (res) {
      setSpellName(res.data.name);
      setDesc(res.data.desc);
      setHigher(res.data.higher_level);
      setRange(res.data.range);
      setLevel(res.data.level);
    });
  };

  var HigherLevel = function HigherLevel() {
    if (higher === undefined) {
      return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}, void 0, false);
    } else {
      return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("b", {
          children: "At Higher Levels:"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 43,
          columnNumber: 19
        }, _this), " ", higher]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 43,
        columnNumber: 16
      }, _this);
    }
  };

  var SpellList = function SpellList() {
    if (spells !== undefined) {
      return spells.map(function (spell) {
        return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
          className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_5___default().card),
          style: {
            display: "block"
          },
          onClick: function onClick() {
            return selectSpell(spell.index);
          },
          children: spell.name
        }, spell.index, false, {
          fileName: _jsxFileName,
          lineNumber: 50,
          columnNumber: 14
        }, _this);
      });
    } else {
      return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        children: "Sorry, an error has occurred!"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 54,
        columnNumber: 12
      }, _this);
    }
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_layout__WEBPACK_IMPORTED_MODULE_3__.default, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("title", {
        children: "Dungeons and Dragons API Browser"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 61,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("meta", {
        name: "description",
        content: "Generated by create next app"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 62,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("link", {
        rel: "icon",
        href: "/favicon.ico"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 63,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 60,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_5___default().mainCard),
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h3", {
        children: spellName
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 66,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("em", {
          children: desc
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 67,
          columnNumber: 12
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 67,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("b", {
          children: "Level:"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 68,
          columnNumber: 12
        }, this), " ", level]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 68,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("b", {
          children: "Range:"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 69,
          columnNumber: 12
        }, this), " ", range]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 69,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(HigherLevel, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 70,
        columnNumber: 10
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 65,
      columnNumber: 9
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h4", {
      style: {
        textAlign: "center"
      },
      children: "More Spells"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 73,
      columnNumber: 5
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_5___default().linkContainer),
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(SpellList, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 75,
        columnNumber: 7
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 74,
      columnNumber: 5
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 59,
    columnNumber: 5
  }, this);
}

_s(Home, "gQDoWJZXeftlTIih7maZR5uDr+8=");

_c = Home;

var _c;

$RefreshReg$(_c, "Home");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvc3BlbGxzLmJmMDJiMjZiODg3ZTU3NWQ4NjM1LmhvdC11cGRhdGUuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFFZSxTQUFTTSxJQUFULEdBQWdCO0FBQUE7O0FBQUE7O0FBQUEsa0JBRUZKLCtDQUFRLENBQUMsRUFBRCxDQUZOO0FBQUEsTUFFdEJLLE1BRnNCO0FBQUEsTUFFZkMsU0FGZTs7QUFBQSxtQkFHTU4sK0NBQVEsQ0FBQyxFQUFELENBSGQ7QUFBQSxNQUd0Qk8sU0FIc0I7QUFBQSxNQUdYQyxZQUhXOztBQUFBLG1CQUlKUiwrQ0FBUSxDQUFDLEVBQUQsQ0FKSjtBQUFBLE1BSXRCUyxJQUpzQjtBQUFBLE1BSWhCQyxPQUpnQjs7QUFBQSxtQkFLQVYsK0NBQVEsQ0FBQyxFQUFELENBTFI7QUFBQSxNQUt0QlcsTUFMc0I7QUFBQSxNQUtkQyxTQUxjOztBQUFBLG1CQU1GWiwrQ0FBUSxDQUFDLEVBQUQsQ0FOTjtBQUFBLE1BTXRCYSxLQU5zQjtBQUFBLE1BTWZDLFFBTmU7O0FBQUEsbUJBT0ZkLCtDQUFRLENBQUMsRUFBRCxDQVBOO0FBQUEsTUFPdEJlLEtBUHNCO0FBQUEsTUFPZkMsUUFQZTs7QUFTN0JmLEVBQUFBLGdEQUFTLENBQUMsWUFBTTtBQUNaRSxJQUFBQSxnREFBQSxDQUFVLEVBQVYsRUFBY2UsSUFBZCxDQUFtQixVQUFBQyxHQUFHLEVBQUk7QUFDMUJiLE1BQUFBLFNBQVMsQ0FBQ2EsR0FBRyxDQUFDQyxJQUFKLENBQVMsQ0FBVCxFQUFZQyxPQUFiLENBQVQ7QUFDQWIsTUFBQUEsWUFBWSxDQUFDVyxHQUFHLENBQUNDLElBQUosQ0FBUyxDQUFULEVBQVlFLElBQWIsQ0FBWjtBQUNBWixNQUFBQSxPQUFPLENBQUNTLEdBQUcsQ0FBQ0MsSUFBSixDQUFTLENBQVQsRUFBWVgsSUFBYixDQUFQO0FBQ0FHLE1BQUFBLFNBQVMsQ0FBQ08sR0FBRyxDQUFDQyxJQUFKLENBQVMsQ0FBVCxFQUFZRyxZQUFiLENBQVQ7QUFDQVQsTUFBQUEsUUFBUSxDQUFDSyxHQUFHLENBQUNDLElBQUosQ0FBUyxDQUFULEVBQVlQLEtBQWIsQ0FBUjtBQUNBRyxNQUFBQSxRQUFRLENBQUNHLEdBQUcsQ0FBQ0MsSUFBSixDQUFTLENBQVQsRUFBWUwsS0FBYixDQUFSO0FBQ0QsS0FQQztBQVFILEdBVFEsRUFTTixFQVRNLENBQVQ7O0FBV0EsTUFBTVMsV0FBVyxHQUFHLFNBQWRBLFdBQWMsQ0FBQ0MsRUFBRCxFQUFRO0FBQ3hCdEIsSUFBQUEsZ0RBQUEsOEVBQWdGc0IsRUFBaEYsR0FBc0ZQLElBQXRGLENBQTJGLFVBQUFDLEdBQUcsRUFBSTtBQUNoR1gsTUFBQUEsWUFBWSxDQUFDVyxHQUFHLENBQUNDLElBQUosQ0FBU0UsSUFBVixDQUFaO0FBQ0FaLE1BQUFBLE9BQU8sQ0FBQ1MsR0FBRyxDQUFDQyxJQUFKLENBQVNYLElBQVYsQ0FBUDtBQUNBRyxNQUFBQSxTQUFTLENBQUNPLEdBQUcsQ0FBQ0MsSUFBSixDQUFTRyxZQUFWLENBQVQ7QUFDQVQsTUFBQUEsUUFBUSxDQUFDSyxHQUFHLENBQUNDLElBQUosQ0FBU1AsS0FBVixDQUFSO0FBQ0FHLE1BQUFBLFFBQVEsQ0FBQ0csR0FBRyxDQUFDQyxJQUFKLENBQVNMLEtBQVYsQ0FBUjtBQUNILEtBTkM7QUFPSCxHQVJEOztBQVVBLE1BQU1XLFdBQVcsR0FBRyxTQUFkQSxXQUFjLEdBQU07QUFDdEIsUUFBSWYsTUFBTSxLQUFLZ0IsU0FBZixFQUEwQjtBQUN0QiwwQkFBTyw2SUFBUDtBQUNILEtBRkQsTUFHSztBQUNILDBCQUFPO0FBQUEsZ0NBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQUgsRUFBNEIsR0FBNUIsRUFBaUNoQixNQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBUDtBQUNEO0FBQ0osR0FQRDs7QUFTQSxNQUFNaUIsU0FBUyxHQUFHLFNBQVpBLFNBQVksR0FBTTtBQUN0QixRQUFJdkIsTUFBTSxLQUFLc0IsU0FBZixFQUEwQjtBQUN4QixhQUFPdEIsTUFBTSxDQUFDd0IsR0FBUCxDQUFXLFVBQUFDLEtBQUssRUFBSTtBQUMzQiw0QkFBTztBQUFHLG1CQUFTLEVBQUUvQixxRUFBZDtBQUE2QyxlQUFLLEVBQUU7QUFBQ2lDLFlBQUFBLE9BQU8sRUFBRTtBQUFWLFdBQXBEO0FBQXdFLGlCQUFPLEVBQUU7QUFBQSxtQkFBTVIsV0FBVyxDQUFDTSxLQUFLLENBQUNHLEtBQVAsQ0FBakI7QUFBQSxXQUFqRjtBQUFBLG9CQUFrSEgsS0FBSyxDQUFDUjtBQUF4SCxXQUFnQ1EsS0FBSyxDQUFDRyxLQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFQO0FBQ0QsT0FGUSxDQUFQO0FBR0gsS0FKQyxNQUtHO0FBQ0gsMEJBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBUDtBQUNEO0FBQ0EsR0FURDs7QUFXQSxzQkFDRSw4REFBQyx1REFBRDtBQUFBLDRCQUNFLDhEQUFDLGtEQUFEO0FBQUEsOEJBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FERixlQUVFO0FBQU0sWUFBSSxFQUFDLGFBQVg7QUFBeUIsZUFBTyxFQUFDO0FBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FGRixlQUdFO0FBQU0sV0FBRyxFQUFDLE1BQVY7QUFBaUIsWUFBSSxFQUFDO0FBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERixlQU1JO0FBQUssZUFBUyxFQUFFbEMseUVBQWhCO0FBQUEsOEJBQ0E7QUFBQSxrQkFBS1E7QUFBTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREEsZUFFQTtBQUFBLCtCQUFHO0FBQUEsb0JBQUtFO0FBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FGQSxlQUdBO0FBQUEsZ0NBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQUgsRUFBaUIsR0FBakIsRUFBc0JNLEtBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUhBLGVBSUE7QUFBQSxnQ0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFBSCxFQUFpQixHQUFqQixFQUFzQkYsS0FBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSkEsZUFLQyw4REFBQyxXQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FMRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFOSixlQWNBO0FBQUksV0FBSyxFQUFFO0FBQUNzQixRQUFBQSxTQUFTLEVBQUU7QUFBWixPQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBZEEsZUFlQTtBQUFLLGVBQVMsRUFBRXBDLDhFQUFoQjtBQUFBLDZCQUNFLDhEQUFDLFNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFmQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQXNCRDs7R0F4RXVCSzs7S0FBQUEiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvc3BlbGxzLmpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBIZWFkIGZyb20gJ25leHQvaGVhZCdcclxuaW1wb3J0IHN0eWxlcyBmcm9tICcuLi9zdHlsZXMvSG9tZS5tb2R1bGUuY3NzJ1xyXG5pbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xyXG5cclxuaW1wb3J0IExheW91dCBmcm9tICcuLi9jb21wb25lbnRzL2xheW91dCc7XHJcbmltcG9ydCBheGlvcyBmcm9tICdheGlvcyc7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBIb21lKCkge1xyXG5cclxuICBjb25zdCBbc3BlbGxzLHNldFNwZWxsc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3NwZWxsTmFtZSwgc2V0U3BlbGxOYW1lXSAgPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZGVzYywgc2V0RGVzY10gID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2hpZ2hlciwgc2V0SGlnaGVyXSAgPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbcmFuZ2UsIHNldFJhbmdlXSAgPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbbGV2ZWwsIHNldExldmVsXSAgPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgYXhpb3MuZ2V0KCcnKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgIHNldFNwZWxscyhyZXMuZGF0YVswXS5yZXN1bHRzKTtcclxuICAgICAgc2V0U3BlbGxOYW1lKHJlcy5kYXRhWzFdLm5hbWUpO1xyXG4gICAgICBzZXREZXNjKHJlcy5kYXRhWzFdLmRlc2MpO1xyXG4gICAgICBzZXRIaWdoZXIocmVzLmRhdGFbMV0uaGlnaGVyX2xldmVsKTtcclxuICAgICAgc2V0UmFuZ2UocmVzLmRhdGFbMV0ucmFuZ2UpO1xyXG4gICAgICBzZXRMZXZlbChyZXMuZGF0YVsxXS5sZXZlbCk7XHJcbiAgICB9KVxyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3Qgc2VsZWN0U3BlbGwgPSAoZWwpID0+IHtcclxuICAgICAgYXhpb3MuZ2V0KGBodHRwczovLzhqeHhiN21nZWMuZXhlY3V0ZS1hcGkudXMtZWFzdC0xLmFtYXpvbmF3cy5jb20vcHJvZC9zcGVsbHMvJHtlbH1gKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgICAgc2V0U3BlbGxOYW1lKHJlcy5kYXRhLm5hbWUpO1xyXG4gICAgICAgIHNldERlc2MocmVzLmRhdGEuZGVzYyk7XHJcbiAgICAgICAgc2V0SGlnaGVyKHJlcy5kYXRhLmhpZ2hlcl9sZXZlbCk7XHJcbiAgICAgICAgc2V0UmFuZ2UocmVzLmRhdGEucmFuZ2UpO1xyXG4gICAgICAgIHNldExldmVsKHJlcy5kYXRhLmxldmVsKTtcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgY29uc3QgSGlnaGVyTGV2ZWwgPSAoKSA9PiB7XHJcbiAgICAgIGlmIChoaWdoZXIgPT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgcmV0dXJuIDw+PC8+XHJcbiAgICAgIH1cclxuICAgICAgZWxzZSB7XHJcbiAgICAgICAgcmV0dXJuIDxwPjxiPkF0IEhpZ2hlciBMZXZlbHM6PC9iPntcIiBcIn17aGlnaGVyfTwvcD47XHJcbiAgICAgIH1cclxuICB9XHJcblxyXG4gIGNvbnN0IFNwZWxsTGlzdCA9ICgpID0+IHtcclxuICAgIGlmIChzcGVsbHMgIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICByZXR1cm4gc3BlbGxzLm1hcChzcGVsbCA9PiB7XHJcbiAgICAgIHJldHVybiA8YSBjbGFzc05hbWU9e3N0eWxlcy5jYXJkfSBrZXk9e3NwZWxsLmluZGV4fSBzdHlsZT17e2Rpc3BsYXk6IFwiYmxvY2tcIn19IG9uQ2xpY2s9eygpID0+IHNlbGVjdFNwZWxsKHNwZWxsLmluZGV4KX0+e3NwZWxsLm5hbWV9PC9hPlxyXG4gICAgfSlcclxuICB9XHJcbiAgZWxzZSB7XHJcbiAgICByZXR1cm4gPGRpdj5Tb3JyeSwgYW4gZXJyb3IgaGFzIG9jY3VycmVkITwvZGl2PlxyXG4gIH1cclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8TGF5b3V0PlxyXG4gICAgICA8SGVhZD5cclxuICAgICAgICA8dGl0bGU+RHVuZ2VvbnMgYW5kIERyYWdvbnMgQVBJIEJyb3dzZXI8L3RpdGxlPlxyXG4gICAgICAgIDxtZXRhIG5hbWU9XCJkZXNjcmlwdGlvblwiIGNvbnRlbnQ9XCJHZW5lcmF0ZWQgYnkgY3JlYXRlIG5leHQgYXBwXCIgLz5cclxuICAgICAgICA8bGluayByZWw9XCJpY29uXCIgaHJlZj1cIi9mYXZpY29uLmljb1wiIC8+XHJcbiAgICAgIDwvSGVhZD5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLm1haW5DYXJkfT5cclxuICAgICAgICA8aDM+e3NwZWxsTmFtZX08L2gzPlxyXG4gICAgICAgIDxwPjxlbT57ZGVzY308L2VtPjwvcD5cclxuICAgICAgICA8cD48Yj5MZXZlbDo8L2I+e1wiIFwifXtsZXZlbH08L3A+XHJcbiAgICAgICAgPHA+PGI+UmFuZ2U6PC9iPntcIiBcIn17cmFuZ2V9PC9wPlxyXG4gICAgICAgIHs8SGlnaGVyTGV2ZWwgLz59XHJcbiAgICAgICAgXHJcbiAgICA8L2Rpdj5cclxuICAgIDxoNCBzdHlsZT17e3RleHRBbGlnbjogXCJjZW50ZXJcIn19Pk1vcmUgU3BlbGxzPC9oND5cclxuICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMubGlua0NvbnRhaW5lcn0+XHJcbiAgICAgIDxTcGVsbExpc3QgLz5cclxuICAgIDwvZGl2PlxyXG4gICAgXHJcbiAgICA8L0xheW91dD5cclxuICApXHJcbn1cclxuIl0sIm5hbWVzIjpbIkhlYWQiLCJzdHlsZXMiLCJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsIkxheW91dCIsImF4aW9zIiwiSG9tZSIsInNwZWxscyIsInNldFNwZWxscyIsInNwZWxsTmFtZSIsInNldFNwZWxsTmFtZSIsImRlc2MiLCJzZXREZXNjIiwiaGlnaGVyIiwic2V0SGlnaGVyIiwicmFuZ2UiLCJzZXRSYW5nZSIsImxldmVsIiwic2V0TGV2ZWwiLCJnZXQiLCJ0aGVuIiwicmVzIiwiZGF0YSIsInJlc3VsdHMiLCJuYW1lIiwiaGlnaGVyX2xldmVsIiwic2VsZWN0U3BlbGwiLCJlbCIsIkhpZ2hlckxldmVsIiwidW5kZWZpbmVkIiwiU3BlbGxMaXN0IiwibWFwIiwic3BlbGwiLCJjYXJkIiwiZGlzcGxheSIsImluZGV4IiwibWFpbkNhcmQiLCJ0ZXh0QWxpZ24iLCJsaW5rQ29udGFpbmVyIl0sInNvdXJjZVJvb3QiOiIifQ==